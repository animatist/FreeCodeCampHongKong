<?php 

include("layout/header.php");

$name = "Jeffrey";

?>

<h1><?php print($name) ?></h1>


<?php

include("layout/header.php");

?>